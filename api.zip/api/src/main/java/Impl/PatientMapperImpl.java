package Impl;

import Model.PatienKIS;
import Model.PatientFHIR;
import mapper.PatientMapper;

import java.util.Locale;


public class PatientMapperImpl implements PatientMapper {
    @Override
    public PatientFHIR toKIS(PatienKIS patienKIS) {
        if (patienKIS == null){
            return null;
        }

        PatientFHIR patient = new PatientFHIR.PatientFHIRBuilder()
        .withid(patienKIS.getId())
        .whitvorname(patienKIS.getVorname())
        .withnachname(patienKIS.getNachname()).build();


        return patient;
    }
}
