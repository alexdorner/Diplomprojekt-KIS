package mapper;

import Model.PatienKIS;
import Model.PatientFHIR;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PatientMapper {
    PatientMapper patientMapper = Mappers.getMapper(PatientMapper.class);

    PatientFHIR toKIS(PatienKIS patienKIS);
}
